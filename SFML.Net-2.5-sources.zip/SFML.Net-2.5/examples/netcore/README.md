# SFML.Net running on .NET Core
This project showcases how SFML.Net can be run on .NET core with NuGet packages.
To execute this example, just run `dotnet run` inside of this directory.

Please note that platform availability is still limited by native CSFML libraries.
For more information on that, check [the main README](/readme.txt).
