# Code style

## VS Code references

VS Code uses Omnisharp.json instead `.editorconfig` for setting up formating style. References to setup can be found [here](https://github.com/OmniSharp/omnisharp-roslyn/wiki/Configuration-Options).