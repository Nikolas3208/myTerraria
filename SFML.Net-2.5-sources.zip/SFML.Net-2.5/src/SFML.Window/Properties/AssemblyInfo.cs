﻿using System.Reflection;
using System.Runtime.InteropServices;

// [assembly: AssemblyTitle("sfml-window")]

[assembly: Guid("c88ebbee-2702-4543-9461-2e92da65156e")]
