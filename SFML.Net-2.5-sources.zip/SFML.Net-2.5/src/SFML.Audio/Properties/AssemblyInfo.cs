﻿using System.Reflection;
using System.Runtime.InteropServices;

// [assembly: AssemblyTitle("sfml-audio")]
//[assembly: AssemblyDescription("Audio module of the SFML library")]

[assembly: Guid("f16e1d68-cc36-440d-a157-0304e9084ab1")]
