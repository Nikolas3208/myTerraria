namespace SFML.System
{
    public static class CSFML
    {
        public const string audio = "csfml-audio";
        public const string graphics = "csfml-graphics";
        public const string system = "csfml-system";
        public const string window = "csfml-window";

    }
}
