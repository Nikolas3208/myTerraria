﻿using System.Reflection;
using System.Runtime.InteropServices;

// [assembly: AssemblyTitle("sfml-graphics")]
//[assembly: AssemblyDescription("Graphics module of the SFML library")]

[assembly: Guid("e6bee356-0d84-48db-a8bd-1288092339a8")]
