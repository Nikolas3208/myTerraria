﻿using System.Reflection;
using System.Runtime.InteropServices;

// [assembly: AssemblyTitle("sfml-system")]
//[assembly: AssemblyDescription("System module of the SFML library")]

[assembly: Guid("f0cec342-7361-41cd-acb4-7ef2461af7f0")]
